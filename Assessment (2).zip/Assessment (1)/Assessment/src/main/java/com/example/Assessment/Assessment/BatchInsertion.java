package com.example.Assessment.Assessment;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

public class BatchInsertion {
	 public static void insertData(List<DataModel> dataList) {
	        try (Connection connection = DatabaseConnection.getConnection();
	             PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO assessmentdb (field1, field2) VALUES (Test, Test)")) {
	            for (DataModel data : dataList) {
	                preparedStatement.setString(1, data.getField1());
	                preparedStatement.setString(2, data.getField2());
	                preparedStatement.addBatch();
	            }
	            preparedStatement.executeBatch();
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }
}
