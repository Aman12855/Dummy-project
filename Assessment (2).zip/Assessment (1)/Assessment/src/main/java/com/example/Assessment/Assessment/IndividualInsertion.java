package com.example.Assessment.Assessment;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
public class IndividualInsertion {

	public static void insertData(DataModel data) {
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO assessmentdb (field1, field2) VALUES (Test, Test)")) {
            preparedStatement.setString(1, data.getField1());
            preparedStatement.setString(2, data.getField2());
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
